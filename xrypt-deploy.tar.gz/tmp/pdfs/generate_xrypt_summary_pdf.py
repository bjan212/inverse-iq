import os
from datetime import datetime

PAGE_WIDTH = 612
PAGE_HEIGHT = 792
MARGIN_LEFT = 54
MARGIN_RIGHT = 54
MARGIN_TOP = 54
MARGIN_BOTTOM = 54
MAX_WIDTH = PAGE_WIDTH - MARGIN_LEFT - MARGIN_RIGHT

TITLE_SIZE = 18
HEADING_SIZE = 12
BODY_SIZE = 10

LEADING_TITLE = 22
LEADING_HEADING = 16
LEADING_BODY = 12

OUTPUT_PATH = "output/pdf/xrypt_app_summary.pdf"


def escape_pdf_text(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace("(", "\\(")
        .replace(")", "\\)")
    )


def estimate_max_chars(font_size: int) -> int:
    # Simple heuristic for Helvetica
    avg_char_width = font_size * 0.52
    return max(1, int(MAX_WIDTH // avg_char_width))


def wrap_text(text: str, font_size: int):
    max_chars = estimate_max_chars(font_size)
    words = text.split()
    lines = []
    current = []
    for word in words:
        tentative = " ".join(current + [word]) if current else word
        if len(tentative) <= max_chars:
            current = (current + [word]) if current else [word]
        else:
            if current:
                lines.append(" ".join(current))
                current = [word]
            else:
                # Very long word fallback
                lines.append(word)
                current = []
    if current:
        lines.append(" ".join(current))
    return lines


def build_lines():
    lines = []

    def add_title(text):
        lines.append(("F2", TITLE_SIZE, text))

    def add_heading(text):
        lines.append(("F2", HEADING_SIZE, text))

    def add_paragraph(text):
        for line in wrap_text(text, BODY_SIZE):
            lines.append(("F1", BODY_SIZE, line))

    def add_bullets(items):
        for item in items:
            wrapped = wrap_text(item, BODY_SIZE)
            for i, line in enumerate(wrapped):
                prefix = "- " if i == 0 else "  "
                lines.append(("F1", BODY_SIZE, f"{prefix}{line}"))

    def add_steps(items):
        for idx, item in enumerate(items, 1):
            wrapped = wrap_text(item, BODY_SIZE)
            for i, line in enumerate(wrapped):
                prefix = f"{idx}. " if i == 0 else "   "
                lines.append(("F1", BODY_SIZE, f"{prefix}{line}"))

    add_title("Xrypt Trading Service - One-Page Summary")

    add_heading("What it is")
    add_paragraph(
        "Xrypt is an AI-powered trading signal generator that uses inverse learning "
        "from trader losses to identify profitable patterns and continuously improve. "
        "It also supports DEX trading execution across multiple chains."
    )

    add_heading("Who it is for")
    add_paragraph(
        "Crypto traders who want AI-generated signals with optional on-chain DEX execution."
    )

    add_heading("What it does")
    add_bullets([
        "Generates AI trading signals with confidence scores and risk levels.",
        "Learns from trader losses and multiple data sources to improve accuracy over time.",
        "Collects public market data and trader submissions for continuous learning.",
        "Integrates DEX trading and multi-chain support (Ethereum, BSC, Arbitrum, Polygon).",
        "Enables Web3 wallet connections for on-chain trade execution.",
        "Exposes REST and WebSocket endpoints for signals, feedback, and notifications."
    ])

    add_heading("How it works")
    add_bullets([
        "Frontend provides a signals UI (signals.html) and Web3 trading interface.",
        "Backend runs an Express server with REST APIs, WebSocket updates, and DEX endpoints.",
        "AI engine (HybridEngine) combines public market data with trader data patterns.",
        "Data collection layer pulls exchange data plus trader submissions and feedback.",
        "Blockchain layer executes on Uniswap V3, PancakeSwap, and QuickSwap."        
    ])

    add_heading("How to run")
    add_steps([
        "Install dependencies: npm install",
        "Create environment file: cp .env.example .env (then edit values)",
        "Configure RPC endpoints: ./scripts/setupRPCConfig.sh",
        "Bootstrap the AI engine: npm run bootstrap",
        "Start the server: npm start (open http://localhost:3000/signals.html)"
    ])

    return lines


def build_pdf(lines):
    content_lines = []
    y = PAGE_HEIGHT - MARGIN_TOP

    def set_font(font_name, size):
        content_lines.append(f"/{font_name} {size} Tf")

    content_lines.append("BT")

    for font_name, size, text in lines:
        if font_name == "F2" and size == TITLE_SIZE:
            y -= LEADING_TITLE
        elif font_name == "F2" and size == HEADING_SIZE:
            y -= LEADING_HEADING
        else:
            y -= LEADING_BODY

        if y < MARGIN_BOTTOM:
            raise RuntimeError("Content overflowed the page. Reduce text or font size.")

        set_font(font_name, size)
        safe_text = escape_pdf_text(text)
        content_lines.append(f"1 0 0 1 {MARGIN_LEFT} {y} Tm ({safe_text}) Tj")

    content_lines.append("ET")
    content_stream = "\n".join(content_lines).encode("utf-8")

    objects = []
    xref_positions = []

    def add_obj(obj_str):
        xref_positions.append(sum(len(o) for o in objects))
        objects.append(obj_str)

    # PDF header
    pdf_parts = [b"%PDF-1.4\n"]

    add_obj("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
    add_obj("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
    add_obj(
        "3 0 obj\n"
        f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
        "/Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>\n"
        "endobj\n"
    )
    add_obj(
        "4 0 obj\n"
        f"<< /Length {len(content_stream)} >>\n"
        "stream\n"
        + content_stream.decode("utf-8")
        + "\nendstream\nendobj\n"
    )
    add_obj("5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n")
    add_obj("6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n")

    # Build xref
    offset = len(pdf_parts[0])
    xref_entries = ["0000000000 65535 f \n"]
    for obj_str in objects:
        xref_entries.append(f"{offset:010d} 00000 n \n")
        offset += len(obj_str.encode("utf-8"))

    pdf_parts.extend(obj.encode("utf-8") for obj in objects)
    xref_start = sum(len(p) for p in pdf_parts)
    xref = "xref\n0 {count}\n".format(count=len(xref_entries)) + "".join(xref_entries)
    trailer = (
        "trailer\n"
        f"<< /Size {len(xref_entries)} /Root 1 0 R >>\n"
        "startxref\n"
        f"{xref_start}\n"
        "%%EOF\n"
    )
    pdf_parts.append(xref.encode("utf-8"))
    pdf_parts.append(trailer.encode("utf-8"))

    with open(OUTPUT_PATH, "wb") as f:
        for part in pdf_parts:
            f.write(part)


if __name__ == "__main__":
    lines = build_lines()
    build_pdf(lines)
    print(OUTPUT_PATH)
